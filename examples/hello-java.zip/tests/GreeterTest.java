import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class GreeterTest {
    @Test public void greetsWorld() {
        assertEquals("Hello, World!", Greeter.greet("World"));
    }
    @Test public void greetsAda() {
        assertEquals("Hello, Ada!", Greeter.greet("Ada"));
    }
}
