// hello-java: make greet(name) return "Hello, <name>!"
public class Greeter {
    public static String greet(String name) {
        return "";
    }

    public static void main(String[] args) {
        java.util.Scanner sc = new java.util.Scanner(System.in);
        System.out.print("Your name: ");
        String who = sc.nextLine();
        System.out.println(greet(who));
    }
}
