# hello-py: make greet(name) return 'Hello, <name>!'

def greet(name):
    return ''

if __name__ == '__main__':
    who = input('Your name: ')
    print(greet(who))
