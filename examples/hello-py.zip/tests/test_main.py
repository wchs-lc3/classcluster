import main

def test_greet_world():
    assert main.greet('World') == 'Hello, World!'

def test_greet_empty():
    assert main.greet('') == 'Hello, !'

def test_greet_name():
    assert main.greet('Ada') == 'Hello, Ada!'
